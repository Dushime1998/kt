<style>
    /* CSS for small screens (phones) */
    @media screen and (max-width: 768px) {
      .responsive {
        display: block;
      }
      .non-responsive {
        display: none;
      }
    }

    /* CSS for large screens (PCs) */
    @media screen and (min-width: 769px) {
      .responsive {
        display: none;
      }
      .non-responsive {
        display: block;
      }
    }
  </style>













    <nav class="bg-red-500 border-gray-200 dark:bg-gray-900">
        <div class="flex flex-wrap justify-between items-center mx-auto max-w-screen-xl p-4">
            <a href="/" class="flex items-center space-x-3 rtl:space-x-reverse">
                <img src="<?php echo e(asset('image/logo.jpg')); ?>" class="h-8 rounded-full" alt="Flowbite Logo" />
                <span class="self-center text-white text-2xl font-semibold whitespace-nowrap dark:text-white">KTZ</span>
            </a>
            <div class="flex items-center space-x-6 rtl:space-x-reverse">
                <a href="tel:5541251234" class="text-sm  text-white dark:text-white hover:underline">(+250) 783-159-293</a>


                <?php if(auth()->check() && !empty(auth()->user()->name)): ?> 
                <button id="dropdownAvatarNameButton" data-dropdown-toggle="dropdownAvatarName" class="flex items-center text-sm pe-1 font-medium text-gray-900 dark:text-white" type="button">
                    <span class="sr-only">Open user menu</span>
                    <?php echo e(auth()->user()->name); ?>

                </button>
            <?php else: ?>
                <a href="<?php echo e(route('loginPage')); ?>" class="text-sm text-white dark:text-blue-500 hover:underline">Login/Register</a>
            <?php endif; ?>



                    <!-- Dropdown menu -->
                    <div id="dropdownAvatarName" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600">
                        <div class="py-2">
                            <a href="<?php echo e(route('logout')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Sign out</a>
                        </div>
                    </div>



<?php if( session('cartTotalQuantity') >0): ?>
<div class="text-center indicator">
    <button class="text-white" type="button" data-drawer-target="drawer-navigation" data-drawer-show="drawer-navigation" aria-controls="drawer-navigation">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
        <span class="badge badge-sm indicator-item"><?php echo e(session('cartTotalQuantity')); ?></span>
    </button>
</div>


<?php else: ?>

<div class="text-center indicator">
    <button class="text-white" type="button" data-drawer-target="drawer-navigation" data-drawer-show="drawer-navigation" aria-controls="drawer-navigation">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
        <span class="badge badge-sm indicator-item">0</span>
    </button>
</div>

<?php endif; ?>


            </div>


        </div>
    </nav>

     <!-- show on only small screen -->


</div>

<!-- end of searchbar -->




        
        




<!-- drawer init and show -->
<!-- drawer component -->
<div id="drawer-navigation" class="fixed top-0 left-0 z-40 w-full h-screen p-4 overflow-y-auto transition-transform -translate-x-full bg-white dark:bg-gray-800" tabindex="-1" aria-labelledby="drawer-navigation-label">
    <h5 id="drawer-navigation-label" class="text-base font-semibold text-gray-500 uppercase dark:text-gray-400">HOME</h5>
    <button type="button" data-drawer-hide="drawer-navigation" aria-controls="drawer-navigation" class="fixed text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5  top-2.5 end-2.5 inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white">
        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
        <span class="sr-only">Close menu</span>
    </button>
    <div class="w-full overflow-y-auto">
        <body>
            <div class="h-screen bg-white pt-20">
                <h1 class="mb-10 text-center text-2xl font-bold">Cart Items</h1>
                <div class="mx-auto max-w-5xl justify-center px-6 md:flex md:space-x-6 xl:px-0">
                    <div class="rounded-lg md:w-2/3">
                        <?php
                        $subtotal = 0; // Initialize subtotal
                        ?>
                        <?php if(session('cart')): ?>
                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $imageArray = json_decode($product['image'], true);
                        $itemTotal = $product['price'] * $product['quantity']; // Calculate item total
                        $subtotal += $itemTotal; // Add to subtotal
                        ?>
                        <div class="justify-between mb-6 rounded-lg bg-white p-6 shadow-md sm:flex sm:justify-start">
                            <?php if($imageArray && isset($imageArray[0])): ?>
                            <img src="<?php echo e(asset('uploads/' . $imageArray[0])); ?>" alt="<?php echo e($product['name']); ?>" class="w-24 h-24 rounded-lg sm:w-40">
                            <?php else: ?>
                            <span>No Image</span>
                            <?php endif; ?>
                            <div class="sm:ml-4 sm:flex sm:w-full sm:justify-between">
                                <div class="mt-5 sm:mt-0">
                                    <h2 class="text-lg font-bold text-gray-900"><?php echo e($product['name']); ?></h2>
                                    <p class="mt-1 text-xs text-gray-700">RWF<?php echo e($product['price']); ?></p>
                                </div>
                                <div class="mt-4 flex justify-between sm:space-y-6 sm:mt-0 sm:block sm:space-x-6">
                                    <div class="flex items-center border-gray-100">
                                        <button class="h-8 w-8 border bg-white text-center text-xs outline-none quantity-remove" data-id="<?php echo e($id); ?>">-</button>
                                        <input class="h-8 w-24 border bg-white text-center text-xs outline-none quantity" type="number" value="<?php echo e($product['quantity']); ?>" min="1" data-price="<?php echo e($product['price']); ?>" data-id="<?php echo e($id); ?>" />
                                        <button class="h-8 w-8 border bg-white text-center text-xs outline-none quantity-add" data-id="<?php echo e($id); ?>">+</button>
                                    </div>
                                    <div class="flex items-center space-x-4">
                                        <p class="text-sm">RWF<?php echo e($itemTotal); ?></p>
                                        <form action="<?php echo e(route('removeFromCart', $product['id'])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5 cursor-pointer duration-150 hover:text-red-500">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                                </svg>
                                            </button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Sub total -->
                    <div class="mt-6 h-full rounded-lg border bg-white p-6 shadow-md md:mt-0 md:w-1/3">
                        <div class="mb-2 flex justify-between">
                            <p class="text-gray-700">Subtotalll</p>
                            <p id="subtotal" class="text-gray-700">$<?php echo e($subtotal); ?></p>
                        </div>
                        <div class="flex justify-between">
                            <p class="text-gray-700">Shipping</p>
                            <p class="text-gray-700">Free</p>
                        </div>
                        <hr class="my-4" />
                        <div class="flex justify-between">
                            <p class="text-lg font-bold">Totall</p>
                            <div class="">
                                <p id="total" class="mb-1 text-lg font-bold">$<?php echo e($subtotal); ?> $USD</p>
                                
                            </div>
                        </div>
                        
                        <?php if(auth()->check() && !empty(auth()->user()->name)): ?>
                        <!-- You can open the modal using ID.showModal() method -->
<button class="btn w-full text-white bg-gray-900 hover:bg-red-700" onclick="my_modal_1.showModal()">Checkout</button>

<?php else: ?>

<button class="btn w-full text-white bg-gray-900 hover:bg-red-700" onclick="my_modal_3.showModal()">Checkout</button>

<?php endif; ?>


<dialog id="my_modal_3" class="modal">
    <div class="modal-box">
      <form method="dialog">
        <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
      </form>
      <p class="py-4">Please Login or create account to continue</p>
    </div>
  </dialog>

<dialog id="my_modal_1" class="modal">
    <div class="modal-box">
      <form method="dialog">
        <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
      </form>



      <form action="<?php echo e(route('payTeste')); ?>" method="post">
        <?php echo csrf_field(); ?>
      <div class="mb-5">

        <input type="amount" name="amount" value="<?php echo e($subtotal); ?>"  class="hidden" />
        <input type="text" name="PayType" value="cart"  class="hidden" />

      </div>
      <div class="mb-5">
          <label for="phone" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Your Phone</label>

          <div class="relative">

              <div class="absolute inset-y-0 start-0 top-0 flex items-center ps-3.5 pointer-events-none">
                  <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 19 18">
                      <path d="M18 13.446a3.02 3.02 0 0 0-.946-1.985l-1.4-1.4a3.054 3.054 0 0 0-4.218 0l-.7.7a.983.983 0 0 1-1.39 0l-2.1-2.1a.983.983 0 0 1 0-1.389l.7-.7a2.98 2.98 0 0 0 0-4.217l-1.4-1.4a2.824 2.824 0 0 0-4.218 0c-3.619 3.619-3 8.229 1.752 12.979C6.785 16.639 9.45 18 11.912 18a7.175 7.175 0 0 0 5.139-2.325A2.9 2.9 0 0 0 18 13.446Z"/>
                  </svg>
              </div>
              <input type="texte"  name="phone" id="phone-input" aria-describedby="helper-text-explanation" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Momo Phone" required />
          </div>
      </div>
      <div class="flex items-start mb-5">

      <button type="submit" class="text-white bg-gray-900 hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">Pay</button>
    </form>

    </div>
</dialog>

  

                        
                    </div>
                    <?php else: ?>
                    <p  class="flex items-center text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.182 16.318A4.486 4.486 0 0 0 12.016 15a4.486 4.486 0 0 0-3.198 1.318M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Z" />
                          </svg>

<span>Your shopping cart is empty </span>



                        </p>
                    <?php endif; ?>
                </div>
            </div>
            </div>
        </body>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Function to update subtotal and total
        function updateTotal() {
            let subtotal = 0;
            document.querySelectorAll('.quantity').forEach(function(item) {
                const price = parseFloat(item.getAttribute('data-price'));
                const quantity = parseInt(item.value);
                subtotal += price * quantity;
                item.parentNode.nextElementSibling.querySelector('p').textContent = 'RWF' + (price * quantity).toFixed(2);
            });
            document.getElementById('subtotal').textContent = 'RWF' + subtotal.toFixed(2);
            document.getElementById('total').textContent = 'RWF' + (subtotal ).toFixed(2) ;
        }

        // Update subtotal and total on page load
        updateTotal();

        // Update subtotal and total on quantity change
        document.querySelectorAll('.quantity').forEach(function(item) {
            item.addEventListener('change', function() {
                updateTotal();
            });
        });

        // Add quantity to cart
        document.querySelectorAll('.quantity-add').forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const input = document.querySelector('.quantity[data-id="' + id + '"]');
                input.value = parseInt(input.value) + 1;
                updateTotal();
            });
        });

        // Remove quantity from cart
        document.querySelectorAll('.quantity-remove').forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const input = document.querySelector('.quantity[data-id="' + id + '"]');
                if (parseInt(input.value) > 1) {
                    input.value = parseInt(input.value) - 1;
                    updateTotal();
                }
            });
        });

        // Remove item from cart
        document.querySelectorAll('.remove-item').forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                fetch("<?php echo e(route('removeFromCart', '')); ?>/" + id, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                })
                .then(response => {
                    if (response.ok) {
                        document.querySelector('.quantity[data-id="' + id + '"]').parentNode.parentNode.parentNode.remove();
                        updateTotal();
                    }
                })
                .catch(error => console.error('Error removing item:', error));
            });
        });
    });
</script>
<?php /**PATH /home/kigakukc/ktz/resources/views/Components/UserNavbar.blade.php ENDPATH**/ ?>