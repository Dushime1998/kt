
    <!-- Fixed Navbar -->
    <div class="fixed w-full z-50">
      <?php echo $__env->make('components.UserNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  
    <div class="pt-16 flex flex-col lg:flex-row bg-gray-100">
  
      <!-- Side Links and New Arrival Section -->
      <div class="lg:w-88 mt-24 p-3 bg-gray-100 non-responsive  ">
        <?php echo $__env->make('components.sideLink2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('components.newArival', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  
      <!-- Main Content Section -->
      <div class="flex-1 w-full mt-24 lg:mx-3 non-responsive">
        <div class="m-4">
         <?php echo $__env->make('components.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       </div>
        <?php echo $__env->make('components.moreTolove', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <div class="flex-1 w-full  lg:mx-3 responsive">
        <?php echo $__env->make('components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.moreTolove', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  
      <!-- Slider Section -->
      <div class="lg:w-88 lg:ml-3 mt-24 lg:mx-3 non-responsive">
        <?php echo $__env->make('components.slider2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  
    </div>
  
    <!-- Pagination Links -->
    <div class="mt-4">
      <?php echo e($accessories->links()); ?>

    </div>
  
    <!-- Footer -->
    <?php echo $__env->make('components.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  </body><?php /**PATH C:\xampp\htdocs\kzz\resources\views/welcome.blade.php ENDPATH**/ ?>