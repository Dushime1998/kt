<div id="default-carousel" class="relative bg-gray-100  w-full" data-carousel="slide">
    <!-- Carousel wrapper -->
    <div class="relative bg-gray-100 h-56 overflow-hidden rounded-lg md:h-96">
         <!-- Item 1 -->
        <div class="hidden duration-900 ease-in-out" data-carousel-item>
            <img src="<?php echo e(asset('image/sound1.jpeg')); ?>"  class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
        <!-- Item 2 -->
        <div class="hidden duration-900 ease-in-out" data-carousel-item>
            <img src="<?php echo e(asset('image/radio/radio1.jpeg')); ?>"  class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
        <!-- Item 3 -->
        <div class="hidden duration-900 ease-in-out" data-carousel-item>
            <img src="<?php echo e(asset('image/radio/radio2.jpeg')); ?>"  class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
        <!-- Item 4 -->
        <div class="hidden duration-900 ease-in-out" data-carousel-item>
            <img src="<?php echo e(asset('image/radio/radio3.jpeg')); ?>"   class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
        <!-- Item 5 -->
        <div class="hidden duration-900 ease-in-out" data-carousel-item>
            <img src="<?php echo e(asset('image/sound1.jpeg')); ?>"  class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
    </div>
    <!-- Slider indicators -->
  
    <!-- Slider controls -->

</div>
<?php /**PATH /home/kigakukc/ktz/resources/views/components/slider2.blade.php ENDPATH**/ ?>