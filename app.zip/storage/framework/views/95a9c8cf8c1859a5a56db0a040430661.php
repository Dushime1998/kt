

          <!-- show on only small screen -->

          <?php echo $__env->make('components.UserNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  




    <!-- boby divs -->

      <div class="flex ">
        <!-- left div -->
        <div class=" h-auto text-center justify-center w-96 ms-3 non-responsive ">
    <!-- category list -->
 <?php echo $__env->make('components.sideLink2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- Centerivision -->
     <div class="bg-gray-50 h-auto w-full">
       <div class="mt-4">

            <div class="mt-5">

                <div class="hero h-98" style="background-image: url(<?php echo e(asset('image/elec1.jpeg')); ?>);">
                    <div class="hero-overlay bg-opacity-60"></div>
                    <div class="hero-content text-center text-neutral-content">
                      <div class="max-w-md">
                        <h1 class="mb-5 text-5xl font-bold">Find Best Technician here</h1>
                        <p class="mb-5">We provide technical suport with high skilled technician.</p>
                        
                      </div>
                    </div>
                  </div>








<div class="grid grid-cols-2 md:grid-cols-2 gap-4 mt-7">
    <div class="w-full">
        <h1 class="text-2xl font-bold">Eectronic support</h1>
        <p class="py-6">We provide household techinal support for repairing , install and reinstall Tv, Radio, Camera.</p>
        <br>
          


    </div>

    <div class="w-full">

       <img class="h-auto max-w-full rounded-lg" src="<?php echo e(asset('image/tronic.jpg')); ?>" alt="">

    </div>
</div>










<div class="grid grid-cols-2 md:grid-cols-2 gap-4 mt-7">
    <div class="w-full">
        <img class="h-auto max-w-full rounded-lg" src="<?php echo e(asset('image/elec1.jpeg')); ?>" alt="">
    </div>

    <div class="w-full">
        <h1 class="font-semibold text-2xl">Electrical Support</h1>
     <p>   We provide electrical support for industrial, domestic, and electrical components. We also troubleshoot electrical systems.</p>
      <br>
      
    </div>
</div>




<div class="grid grid-cols-2 md:grid-cols-2 gap-4 mt-7">
    <div class="w-full">
        <h1 class="font-semibold text-2xl">Tlecommunication Support</h1>
        <p>   We provide electrical support for mounting and remounting Canal+, DSTV, and STARTIMES dishes.</p>
         <br>
          


    </div>

    <div class="w-full">

       <img class="h-auto max-w-full rounded-lg" src="<?php echo e(asset('image/decoder/dstv4.jpeg')); ?>" alt="">

    </div>
</div>


             </div>
       </div>
     </div>






        <div class="bg-white h-auto w-96 ml-3 non-responsive">


              <div class="image-slider mt-4 h-auto ">
            <?php echo $__env->make('components.slider2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


        </div>
      </div>




    <!-- footer -->

<?php echo $__env->make('components.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\kzz\resources\views/suportPage.blade.php ENDPATH**/ ?>