<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>
<body>


          <!-- show on only small screen -->

          <?php echo $__env->make('Components.UserNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  




    <!-- boby divs -->

      <div class="flex ">
        <!-- left div -->
        <div class=" h-auto text-center justify-center w-96 ms-3 non-responsive ">
    <!-- category list -->
<?php echo $__env->make('Components.sideLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>

        <!-- Centerivision -->
     <div class="bg-white h-auto w-full">
        
        <form class="max-w-lg mx-auto responsive ">
            <div class="flex">
                <label for="search-dropdown" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Your Email</label>
                <button id="dropdown-button" data-dropdown-toggle="dropdown" class="flex-shrink-0 z-10 inline-flex items-center py-2.5 px-4 " type="button">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0ZM3.75 12h.007v.008H3.75V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm-.375 5.25h.007v.008H3.75v-.008Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
                      </svg>
                </button>
                <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                    <?php echo $__env->make('Components.sideLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="relative w-full">
                    <input type="search" id="search-dropdown" class="block p-2.5 h-full w-full z-20 text-sm text-gray-900 bg-gray-50 rounded-e-lg border-s-gray-50 border-s-2 border border-gray-300 focus:ring-gray-500 focus:border-gray-500 dark:bg-gray-700 dark:border-s-gray-700  dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-gray-500" placeholder="Search product name, price..." required />
                    <button type="submit" class="absolute top-0 end-0 p-2.5 text-sm font-medium h-full text-white bg-gray-900 rounded-e-lg border border-gray-900 hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-blue-600">
                        <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                        </svg>
                        <span class="sr-only">Search</span>
                    </button>
                </div>
            </div>
        </form>
        
       <div class="mt-4">



    <div class="mt-5">
        <input type="text"  id="search" name="searchQuery" placeholder="Search for product name or price ...." class="mt-4 mb-4 p-2 border border-gray-300 rounded-md w-full non-responsive">

      <h1 class="font-semibold t text-2xl text-red-500">Result For <?php echo e($id); ?></h1>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2 "id="dataGrid">
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $array = json_decode($product->fileName);
        ?>

        <div   class="product">
            <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">
                <a href="<?php echo e(route('products_show', ['productId' => $product->id])); ?>">

                    <img src="<?php echo e(asset('uploads/' . $array[0])); ?>" class="w-full h-56 object-cover rounded-t-lg" alt="product image" />
                </a>
                <div class="px-4 py-4">
                    <a href="<?php echo e(route('products_show', ['productId' => $product->id])); ?>" class="block">
                        <h5 class="text-sm font-semibold tracking-tight text-gray-900 dark:text-white">
                            <?php echo e($product->productName); ?>

                        </h5>
                    </a>

                    <div class="flex items-center justify-between mt-2">
                        <span class="text-sm font-bold text-gray-900 dark:text-white">FRW <?php echo e($product->productPrice); ?></span>
                        <a href="<?php echo e(route('addTocart', ['id' => $product->id])); ?>" class="rounded-lg tooltip text-black" data-tip="Add To Cart">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 tooltip" data-tip="hello">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
      </div>
       </div>
     </div>






        <div class="bg-white h-auto w-96 ml-3 non-responsive">


              <div class="image-slider mt-4 h-32 ">
            <?php echo $__env->make('Components.slider2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


             <div class="border-rounded-full  items-center ml-4 mt-4">

            </div>

            <div class=" mt-7">

            </div>



        </div>
      </div>




    <!-- footer -->
<?php echo $__env->make('Components.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>




<script>
    // Get the search input element
    const searchInput = document.getElementById('search');

    const items = document.querySelectorAll('.product');


    searchInput.addEventListener('input', function () {

        const searchValue = this.value.toLowerCase();

        items.forEach(item => {

            const itemTextContent = item.textContent.toLowerCase();
            // Check if the search value is included in the item's text content
            if (itemTextContent.includes(searchValue)) {
                // Show the item if it includes the search value
                item.style.display = 'block';
            } else {
                // Hide the item if it doesn't include the search value
                item.style.display = 'none';
            }
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\Remy\resources\views/searchResult.blade.php ENDPATH**/ ?>