

<footer class="footer p-10 bg-gray-900 text-white mt-4 mb-2">
    <aside>
        <img src="" class="h-12 w-12 rounded-full align-middle "  alt="Image" />
      <p>KTZ Ltd.<br>Providing reliable tech since 2010</p>
    </aside>
    <nav>
      <h6 class="footer-title font-semibold text-xl">Services</h6>
      <a class="">Network Repair & Accessories</a>
      <a class="">CCTV Camera Installation</a>
      <a class="">Computers and Accessories</a>
      <a class="">All Types of Cables</a>
      <a class="">Sound System Renting</a>
      <a class="">Anti-Virus & Software Repair</a>
      <a class="">Electric Billboard</a>
    </nav>

    <nav>
      <h6 class="footer-title font-semibold text-xl">Company</h6>
      <a class="">About us</a>
      <a class="">Contact</a>
      <a class="">News</a>

    </nav>
    <nav>
      <h6 class="footer-title font-semibold text-xl">Social Media</h6>
      <a class="link link-hover">Terms of use</a>
      <a class="link link-hover">Privacy policy</a>

    </nav>
  </footer>
<?php /**PATH C:\xampp\htdocs\Remy\resources\views/Components/userFooter.blade.php ENDPATH**/ ?>