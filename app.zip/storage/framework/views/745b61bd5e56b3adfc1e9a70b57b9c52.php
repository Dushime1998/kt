<nav class="bg-gray-100 m-4 dark:bg-gray-700">
    <div class="max-w-screen-xl px-4 py-3 mx-auto">
        <div class="flex items-center">
            <ul class="flex flex-row font-medium mt-0 space-x-8 rtl:space-x-reverse text-sm">
<?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    


                <li>
                    <a href="<?php echo e(route('check-category', ['id' => $item->subCategory])); ?>" class="text-gray-900 dark:text-white hover:underline" aria-current="page"><?php echo e($item->subCategory); ?></a>
                </li>
                

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\kzz\resources\views/category/subCategory.blade.php ENDPATH**/ ?>