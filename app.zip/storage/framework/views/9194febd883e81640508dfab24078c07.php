<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>
<body class="bg-gray-100">


<?php echo $__env->make('components.UserNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>







      <div class="flex  bg-gray-100 ">

        <!-- left div -->

        <div class=" h-auto text-center justify-center w-96 ms-3 bg-gray-100 non-responsive ">
        <?php echo $__env->make('components.sideLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        
        <h1 class="text-center font-bold ">New Arrival</h1>
        
        <div class="overflow-auto h-auto text-justify">
            
            
             <?php $__currentLoopData = $arrival; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrived): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $array = json_decode($arrived->fileName);
                ?>
       

                    
                    <div class="card w-48 bg-base-100 shadow-xl py-4 mt-4">
  <figure>
                      <a href="<?php echo e(route('products_show', ['productId' => $arrived->id])); ?>">
                        <img src="<?php echo e(asset('uploads/' . $array[0])); ?>" class="w-24 h-32 object-cover rounded-t-lg  transition-transform  hover:scale-110" alt="product image" />
                    </a>
  </figure>
  
  <div class="card-body">
    <h2 class="card-title">
      Delivery
      <div class="bg-red-500 text-white px-1 py-0.5 rounded-lg text-xs">Free</div>
    </h2>
    <p>Remote for all tv </p>
    <div class="card-actions justify-end">
      <div class="badge badge-outline">Electronic</div> 
     
    </div>
  </div>
</div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
         
            </div>
        </div>



        <div class="bg-gray-100 h-auto w-full ">
             
             <form action="<?php echo e(route('product_search')); ?>" method="GET" class="w-full mx-auto mt-4 non-responsive">
                <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
                <div class="relative">
                    <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                        </svg>
                    </div>
                    <input type="search" id="search" name="search" class="block w-full p-4 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search product name or price..." required />
                   <button type="submit" class="text-white absolute end-2.5 bottom-2.5 bg-gradient-to-r from-gray-700 to-gray-600 hover:from-gray-800 hover:to-gray-700 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-gray-600 dark:hover:from-gray-800 dark:hover:to-gray-700 dark:focus:ring-gray-800">Search</button>

                <!--<button type="button" class="text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 shadow-lg shadow-blue-500/50 dark:shadow-lg dark:shadow-blue-800/80 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2 ">Blue</button>-->

                </div>
            </form>





<form action="<?php echo e(route('product_search')); ?>"class="max-w-lg mx-auto responsive ">
    <div class="flex">
        <label for="search-dropdown" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Your Email</label>
        <button id="dropdown-button" data-dropdown-toggle="dropdown" class="flex-shrink-0 z-10 inline-flex items-center py-2.5 px-4 " type="button">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0ZM3.75 12h.007v.008H3.75V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm-.375 5.25h.007v.008H3.75v-.008Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
              </svg>
        </button>
        <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
            <?php echo $__env->make('components.sideLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="relative w-full">
            <input type="search" name="search" id="search-dropdown" class="block p-2.5 h-full w-full z-20 text-sm text-gray-900 bg-gray-50 rounded-e-lg border-s-gray-50 border-s-2 border border-gray-300 focus:ring-gray-500 focus:border-gray-500 dark:bg-gray-700 dark:border-s-gray-700  dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-gray-500" placeholder="Search product name, price..." required />
            <button type="submit" class="text-white absolute end-2.5 bottom-2.5 bg-gradient-to-r from-gray-700 to-gray-600 hover:from-gray-800 hover:to-gray-700 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-gray-600 dark:hover:from-gray-800 dark:hover:to-gray-700 dark:focus:ring-gray-800">
                  <svg class="w-4 h-4 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                </svg>
            </button>
            

        </div>
    </div>
</form>



<div class="mt-4">
    <!-- Title -->
    <h1 class="text-gray-900 font-medium bg-gray-100  text-2xl">
     Deal of The week
     
     <div class="badge bg-red-600" style="background-color:red; color:white"> Discounted</div>
    </h1>
    <!-- Grid of products -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4" >

        <?php $__currentLoopData = $topElectronic->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summirizedElc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Loop through each product in the chunk -->
            <?php $__currentLoopData = $summirizedElc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $electronic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $array = json_decode($electronic->fileName);
                ?>
                <!-- Product card -->
                <div class="product">
                    <!-- Product image -->
                    <span class="bg-red-500 text-white px-2 py-1  rounded-bl-lg rounded-tr-lg">-<?php echo e($electronic->discount); ?>%</span>

                    <a href="<?php echo e(route('products_show', ['productId' => $electronic->id])); ?>">
                        <img src="<?php echo e(asset('uploads/' . $array[0])); ?>" class="w-full h-56 object-cover rounded-t-lg  transition-transform  hover:scale-110" alt="product image" />
                    </a>
                    <!-- Product details -->
                    <div class="w-full max-w-sm bg-white  shadow-lg dark:bg-gray-800 ">
                        <div class="px-4 py-4">
                            <!-- Product name -->
                            <a href="<?php echo e(route('products_show', ['productId' => $electronic->id])); ?>" class="block">
                                <h5 class="text-sm font-semibold tracking-tight text-gray-900 dark:text-white">
                                    <?php echo e(substr($electronic->productName, 0, 15)); ?><?php echo e(strlen($electronic->productName) > 15 ? '...' : ''); ?>

                                </h5>
                            </a>
                            <!-- Product price and Add to Cart button -->
                            <div class="flex items-center justify-between mt-2">
                                <!-- Product price -->
                             <h1 class="font-semibold text-xs">
                                     <span class="text-xs">RWF</span>
                                     <span class="text-sm font-bold text-gray-900 dark:text-white"><?php echo e($electronic->productPrice); ?></span>
                             </h1>

                                <!-- Add to Cart button -->
                                <a href="<?php echo e(route('addTocart', ['id' => $electronic->id])); ?>" class="rounded-lg tooltip text-black" data-tip="Add To Cart">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 tooltip" data-tip="hello">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    
    
    
    
    
    <!-- Accessories section -->
           <div class="container mx-auto non-responsive ml-16 mt-7">
            <h1 class="text-gray-900 font-semibold text-start text-2xl">More to love</h1>
            <div class="grid grid-cols-6 md:grid-cols-6 gap-6 " id="dataGrid">
                
                <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $array = json_decode($accessory->fileName);
                ?>
               <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">
    <?php if($accessory->Badge =='0'): ?>
        <span class="bg-red-500 text-white px-1 py-0.5 rounded-lg text-xs hidden">New</span>
    <?php else: ?>
        <span class="bg-red-500 text-white px-1 py-0.5 rounded-lg text-xs"><?php echo e($accessory->Badge); ?></span>
    <?php endif; ?>

    <a href="<?php echo e(route('products_show', ['productId' => $accessory->id])); ?>" class=" block overflow-hidden">
        <img src="<?php echo e(asset('uploads/' . $array[0])); ?>" alt="<?php echo e($accessory->productName); ?>" class="w-full h-24 object-cover rounded-t-lg transition-transform  hover:scale-110" />
    </a>
    
    <div class="px-4 py-4">
        <a href="<?php echo e(route('products_show', ['productId' => $accessory->id])); ?>">
            <h5 class="text-xs truncate-text font-semibold tracking-tight text-gray-900 dark:text-white">
              <?php echo e(substr($accessory->productName, 0, 10)); ?><?php echo e(strlen($accessory->productName)> 15 ? '...' : ''); ?>

            </h5>
        </a>
        
        <div class="flex items-center justify-between mt-2">
            <h1 class="font-semibold text-xs">
                <span class="text-xs">Rwf</span>
                <span class="text-xs font-bold text-gray-900 dark:text-white"><?php echo e($accessory->productPrice); ?></span>
            </h1>
            
            <a href="<?php echo e(route('addTocart', ['id' => $accessory->id])); ?>" class="rounded-lg tooltip text-black" data-tip="Add To Cart">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 tooltip" data-tip="hello">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
                </svg>
            </a>
            
        </div>
    </div>
</div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div>

            

</div>


            <!-- Telecommunication section -->



        </div>


        <div class="  bg-gray-100 h-auto w-96 ml-3 non-responsive px-6">
           
        <?php echo $__env->make('components.slider2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
       <h1 class="font-bold text-2xl">
           Tech Support
       </h1>
           
           
            <!-- tech support div-->
            
            

<div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 px-6 mt-4">
    <a href="#">
        <img class="rounded-t-lg" src="<?php echo e(asset('image/cctv.jpeg')); ?>" alt="" />
    </a>
    <div class="p-5">
        <a href="#">
            <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">CCTV Camera Installation and Repair</h5>
        </a>
      <a href="#" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-red-900 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
            Read more
             <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
            </svg>
        </a>
    </div>
</div>


<div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 px-6 mt-4">
    <a href="#">
        <img class="rounded-t-lg" src="<?php echo e(asset('image/tvvv.PNG')); ?>" alt="" />
    </a>
    <div class="p-5">
        <a href="#">
            <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Decoder and TV installation</h5>
        </a>
      <a href="#" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-red-900 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
            Read more
             <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
            </svg>
        </a>
    </div>
</div>



<div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 px-6 mt-4">
    <a href="#">
        <img class="rounded-t-lg" src="<?php echo e(asset('image/ist.jpg')); ?>" alt="" />
    </a>
    <div class="p-5">
        <a href="#">
            <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Domestic and Industrial Installation</h5>
        </a>
      <a href="#" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-red-900 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
            Read more
             <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
            </svg>
        </a>
    </div>
</div>


<!--end of tech support-->

        </div>
      </div>




           


           <!-- Accessories section -->
           <div class="container mx-auto responsive mt-4 px-4">
            <h1 class="text-gray-900 font-semibold text-start text-2xl">More to love</h1>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 " id="dataGrid">
                
                <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $array = json_decode($accessory->fileName);
                ?>
                <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700 ">
                  <?php if($accessory->Badge =='0'): ?>
                   <span class="bg-red-500 text-white px-2 py-1 absolute rounded-bl-lg rounded-tr-lg hidden">New</span>
                   <?php else: ?>
                   <span class="bg-red-500 text-white px-2 py-1 absolute rounded-bl-lg rounded-tr-lg"><?php echo e($accessory->Badge); ?></span>
                   <?php endif; ?>
                    <a href="<?php echo e(route('products_show', ['productId' => $accessory->id])); ?>">
                        <img src="<?php echo e(asset('uploads/' . $array[0])); ?>" alt="<?php echo e($accessory->productName); ?>" class="w-full h-56  object-cover rounded-t-lg" />

                    </a>
                    <div class="px-4 py-4">
                        <a href="<?php echo e(route('products_show', ['productId' => $accessory->id])); ?>">

                            <h5 class="text-sm truncate-text font-semibold tracking-tight text-gray-900 dark:text-white">

                                <?php echo e(substr($accessory->productName, 0, 15)); ?><?php echo e(strlen($accessory->productName) > 15 ? '...' : ''); ?>

                            </h5>
                        </a>

                        <div class="flex items-center justify-between mt-2">
                            <span class="text-sm font-bold text-gray-900 dark:text-white">RWF <?php echo e($accessory->productPrice); ?></span>
                            <a href="<?php echo e(route('addTocart', ['id' => $accessory->id])); ?>" class="rounded-lg tooltip text-black" data-tip="Add To Cart">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 tooltip" data-tip="hello">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

<!--<div class="flex justify-center mt-8">-->
<!--    <nav class="bg-green-500 rounded-lg p-4">-->
<!--        <?php echo e($accessories->links()); ?>-->
<!--    </nav>-->
<!--</div>-->

    <!-- footer -->
    <?php echo $__env->make('components.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>












  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>


<script>
    // Get the search input element
    const searchInput = document.getElementById('search');
    // Get all the items
    const items = document.querySelectorAll('.accessories');

    // Add event listener for input event on search input
    searchInput.addEventListener('input', function () {
        // Get the search value
        const searchValue = this.value.toLowerCase();

        // Loop through each item
        items.forEach(item => {
            // Get the text content of the item
            const itemTextContent = item.textContent.toLowerCase();
            // Check if the search value is included in the item's text content
            if (itemTextContent.includes(searchValue)) {
                // Show the item if it includes the search value
                item.style.display = 'block';
            } else {
                // Hide the item if it doesn't include the search value
                item.style.display = 'none';
            }
        });
    });
</script>
<?php /**PATH /home/kigakukc/ktz/resources/views/welcome.blade.php ENDPATH**/ ?>