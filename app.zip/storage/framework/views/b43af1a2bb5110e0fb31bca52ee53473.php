<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>
<body>


          <!-- show on only small screen -->

          <?php echo $__env->make('Components.UserNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  




    <!-- boby divs -->

      <div class="flex ">
        <!-- left div -->
        <div class=" h-auto text-center justify-center w-96 ms-3 ">
    <!-- category list -->
 <?php echo $__env->make('Components.sideLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- Centerivision -->
     <div class="bg-gray-50 h-auto w-full">
       <div class="mt-4">

            <div class="mt-5">

                <div class="hero h-98" style="background-image: url(<?php echo e(asset('image/elec1.jpeg')); ?>);">
                    <div class="hero-overlay bg-opacity-60"></div>
                    <div class="hero-content text-center text-neutral-content">
                      <div class="max-w-md">
                        <h1 class="mb-5 text-5xl font-bold">Find Best Technician here</h1>
                        <p class="mb-5">We provide technical suport with high skilled technician.</p>
                        <button class="btn btn-primary">Find technician Now</button>
                      </div>
                    </div>
                  </div>








<div class="grid grid-cols-2 md:grid-cols-2 gap-4 mt-7">
    <div class="w-full">
        <h1 class="text-2xl font-bold">Eectronic support</h1>
        <p class="py-6">We provide household techinal support for repairing , install and reinstall Tv, Radio, Camera.</p>
        <br>
          <button class="btn bg-gray-900 text-white">Get Thechnician </button>


    </div>

    <div class="w-full">

       <img class="h-auto max-w-full rounded-lg" src="<?php echo e(asset('image/tronic.jpg')); ?>" alt="">

    </div>
</div>










<div class="grid grid-cols-2 md:grid-cols-2 gap-4 mt-7">
    <div class="w-full">
        <img class="h-auto max-w-full rounded-lg" src="<?php echo e(asset('image/elec1.jpeg')); ?>" alt="">
    </div>

    <div class="w-full">
        <h1 class="font-semibold text-2xl">Electrical Support</h1>
     <p>   We provide electrical support for industrial, domestic, and electrical components. We also troubleshoot electrical systems.</p>
      <br>
      <button class="btn bg-gray-900 text-white">Get Thechnician </button>
    </div>
</div>




<div class="grid grid-cols-2 md:grid-cols-2 gap-4 mt-7">
    <div class="w-full">
        <h1 class="font-semibold text-2xl">Tlecommunication Support</h1>
        <p>   We provide electrical support for mounting and remounting Canal+, DSTV, and STARTIMES dishes.</p>
         <br>
          <button class="btn bg-gray-900 text-white">Get Thechnician </button>


    </div>

    <div class="w-full">

       <img class="h-auto max-w-full rounded-lg" src="<?php echo e(asset('image/decoder/dstv4.jpeg')); ?>" alt="">

    </div>
</div>


             </div>
       </div>
     </div>






        <div class="bg-white h-auto w-96 ml-3">


              <div class="image-slider mt-4 h-32 ">
            <?php echo $__env->make('Components.slider2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


             <div class="border-rounded-full  items-center ml-4 mt-4">

            </div>

            <div class=" mt-7">

            </div>



        </div>
      </div>




    <!-- footer -->

<?php echo $__env->make('Components.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Remy\resources\views/suportPage.blade.php ENDPATH**/ ?>