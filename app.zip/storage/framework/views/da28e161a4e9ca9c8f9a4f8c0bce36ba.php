

<?php echo $__env->make('Admin.AdminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('Admin.adminSidelink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <div class="p-4 sm:ml-64 mt-4">
    <div class=" rounded-lg dark:border-gray-700">


        <div class="mt-5">
            <h1 class="text-center font-semibold text-gray-950">Add New Items</h1>
        </div>
          <div class="justify-center flex mt-4 ">
            <form class="ml-10 ms-10 w-96 justify-items-center"   action="<?php echo e(route('StoreNewType')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-6">
        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">New Type Name</label>
        <input type="text" name="name" id="name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Enter product name" required />
         </div>


      <div class="mb-6 ">

        <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white" for="file_input">Write New Type Description</label>
        <textarea id="description" name="description" rows="4" class=" border border-gray-300 rounded-lg w-full px-0 text-sm text-gray-900 bg-white  dark:bg-gray-800 focus:ring-0 dark:text-white dark:placeholder-gray-400" placeholder="Write product description..." required></textarea>

      </div>


    <button type="submit" class="text-white bg-gray-900 hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">Submit New Type</button>

      </div>



</form>

</div>
</div>
</div>
</div>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Remy\resources\views/Admin/AddNewType.blade.php ENDPATH**/ ?>