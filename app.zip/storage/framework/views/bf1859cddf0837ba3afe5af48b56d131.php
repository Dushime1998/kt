<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>
<body class="bg-gray-100">
<!-- Responsive Div -->


  <!-- Responsive Div (For Phones) -->
  <div class="bg-gray-200 text-center py-4 responsive">
      <p class="text-xl">Hello, World! (Responsive)</p>
  </div>

  <!-- Non-Responsive Div (For PC Screens) -->
  <div class="bg-gray-300 text-center py-4 non-responsive">
      <p class="text-xl">Hello, World! (Non-Responsive)</p>
  </div>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\Remy\resources\views/note.blade.php ENDPATH**/ ?>