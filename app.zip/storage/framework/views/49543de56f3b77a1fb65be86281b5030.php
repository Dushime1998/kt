<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

<div id="app"><?php echo e(message); ?></div>

<script>
  const { createApp, ref } = Vue

  createApp({
    setup() {
      const message = ref('Hello vue!')
      return {
        message
      }
    }
  }).mount('#app')
</script><?php /**PATH C:\xampp\htdocs\kzz\resources\views/note.blade.php ENDPATH**/ ?>