

<?php echo $__env->make('components.UserNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="flex flex-col lg:flex-row bg-gray-100">

    <div class="h-auto text-center justify-center lg:w-96 ms-3 bg-gray-100 non-responsive">
          <?php echo $__env->make('components.sideLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->make('components.newArival', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     </div>

    <div class="bg-gray-100 h-auto w-full lg:mx-3 mt-4">
           <?php echo $__env->make('components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.moreTolove', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


    <div class="bg-gray-100 h-auto w-full lg:w-96 lg:ml-3 non-responsive px-6">
          <?php echo $__env->make('components.slider2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>

<!-- Pagination -->
<div class="mt-4">
    <?php echo e($accessories->links()); ?>

</div>

<!-- Footer -->
<?php echo $__env->make('components.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>


<script>
    // Get the search input element
    const searchInput = document.getElementById('search');
    // Get all the items
    const items = document.querySelectorAll('.accessories');

    // Add event listener for input event on search input
    searchInput.addEventListener('input', function () {
        // Get the search value
        const searchValue = this.value.toLowerCase();

        // Loop through each item
        items.forEach(item => {
            // Get the text content of the item
            const itemTextContent = item.textContent.toLowerCase();
            // Check if the search value is included in the item's text content
            if (itemTextContent.includes(searchValue)) {
                // Show the item if it includes the search value
                item.style.display = 'block';
            } else {
                // Hide the item if it doesn't include the search value
                item.style.display = 'none';
            }
        });
    });
</script>
<?php /**PATH /home/kigakukc/kzz/resources/views/welcome.blade.php ENDPATH**/ ?>