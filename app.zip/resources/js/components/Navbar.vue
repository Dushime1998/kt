<template>
    <div>

<!-- boby divs -->

  <div class="flex ">

    <!-- left div -->
    <div class=" h-auto text-center justify-center w-96 ms-3 ">

<!-- category list -->
        <h1 class="text-center text-black font-semibold">
            Categories
        </h1>

        <ul class="menu   w-56 rounded-box">
            <li>
              <a>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 20.25h12m-7.5-3v3m3-3v3m-10.125-3h17.25c.621 0 1.125-.504 1.125-1.125V4.875c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125Z" />
                  </svg>

             TV
              </a>
            </li>
            <li>
              <a>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m3.75 7.5 16.5-4.125M12 6.75c-2.708 0-5.363.224-7.948.655C2.999 7.58 2.25 8.507 2.25 9.574v9.176A2.25 2.25 0 0 0 4.5 21h15a2.25 2.25 0 0 0 2.25-2.25V9.574c0-1.067-.75-1.994-1.802-2.169A48.329 48.329 0 0 0 12 6.75Zm-1.683 6.443-.005.005-.006-.005.006-.005.005.005Zm-.005 2.127-.005-.006.005-.005.005.005-.005.005Zm-2.116-.006-.005.006-.006-.006.005-.005.006.005Zm-.005-2.116-.006-.005.006-.005.005.005-.005.005ZM9.255 10.5v.008h-.008V10.5h.008Zm3.249 1.88-.007.004-.003-.007.006-.003.004.006Zm-1.38 5.126-.003-.006.006-.004.004.007-.006.003Zm.007-6.501-.003.006-.007-.003.004-.007.006.004Zm1.37 5.129-.007-.004.004-.006.006.003-.004.007Zm.504-1.877h-.008v-.007h.008v.007ZM9.255 18v.008h-.008V18h.008Zm-3.246-1.87-.007.004L6 16.127l.006-.003.004.006Zm1.366-5.119-.004-.006.006-.004.004.007-.006.003ZM7.38 17.5l-.003.006-.007-.003.004-.007.006.004Zm-1.376-5.116L6 12.38l.003-.007.007.004-.004.007Zm-.5 1.873h-.008v-.007h.008v.007ZM17.25 12.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5Zm0 4.5a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5Z" />
                  </svg>

             Radio
              </a>
            </li>
            <li>
              <a>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9.348 14.652a3.75 3.75 0 0 1 0-5.304m5.304 0a3.75 3.75 0 0 1 0 5.304m-7.425 2.121a6.75 6.75 0 0 1 0-9.546m9.546 0a6.75 6.75 0 0 1 0 9.546M5.106 18.894c-3.808-3.807-3.808-9.98 0-13.788m13.788 0c3.808 3.807 3.808 9.98 0 13.788M12 12h.008v.008H12V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
                  </svg>


               Dishes
              </a>
            </li>


            <li>
                <a>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 6.878V6a2.25 2.25 0 0 1 2.25-2.25h7.5A2.25 2.25 0 0 1 18 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 0 0 4.5 9v.878m13.5-3A2.25 2.25 0 0 1 19.5 9v.878m0 0a2.246 2.246 0 0 0-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0 1 21 12v6a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 18v-6c0-.98.626-1.813 1.5-2.122" />
                      </svg>



                 Decoder
                </a>
              </li>

              <li>
                <a>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z" />
                      </svg>



Accessories
                </a>
              </li>


              <li>
                <a>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 1 1-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 0 0 4.486-6.336l-3.276 3.277a3.004 3.004 0 0 1-2.25-2.25l3.276-3.276a4.5 4.5 0 0 0-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437 1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008Z" />
                      </svg>
                  Support
                </a>
              </li>
          </ul>

<!-- sound animation div -->

          <div class="image-slider mt-4">
            <h1 class="text-red-700 font-semibold">Sound System</h1>
            <img :src="currentImageSound" alt="Slider Image"  class="rounded-5"/>
          </div>
    </div>




 <div class="bg-white h-auto w-full">
    <div class="mt-4">

        <input type="text" v-model="searchQuery" placeholder="Search for product name or price ...." class="mt-4 mb-4 p-2 border border-gray-300 rounded-md w-full">

        <h1 class="text-red-500 font-semibold">
            Top Brand
        </h1>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
        <div v-for="(product, index) in filteredElectronics" :key="index" class="product">

            <img :src="product.filePath" :alt="product.productName" class="w-full h-56 object-cover rounded-t-lg" alt="product image" />

    <div>
        <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">

            <!-- </a> -->
            <div class="px-4 py-4">
                <a :href="'/products/' + product.id" class="block">
                    <h5 class="text-sm font-semibold tracking-tight text-gray-900 dark:text-white">
                        {{ product.productName }}</h5>
                </a>

                <div class="flex items-center justify-between mt-2">
                    <span class="text-sm font-bold text-gray-900 dark:text-white">RWF {{ product.productPrice }}  </span>
                    <button @click="addToCart(product.productId, 1)" class="text-xs px-3 py-2 rounded-lg bg-gray-900 hover:bg-blue-600 text-white">Add to Cart</button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<!-- tlecommunication section -->


<div class="mt-4">
    <h1 class="text-red-500 font-semibold">
     Telecommunication
    </h1>
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">


    <!-- <div v-for="(telecom, index) in tlecommunication" :key="index" class="product"> -->
        <div v-for="(telecom, index) in filteredTelecommunication" :key="index" class="product">
        <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <a :href="'/products/' + telecom.id" class="block">
                <img :src="telecom.filePath" :alt="telecom.productName" class="w-full h-56 object-cover rounded-t-lg" alt="product image" />

            </a>
            <div class="px-4 py-4">
                <a :href="'/products/' + telecom.id" class="block">
                    <h5 class="text-sm font-semibold tracking-tight text-gray-900 dark:text-white">
                        {{ telecom.productName }}</h5>
                </a>

                <div class="flex items-center justify-between mt-2">
                    <span class="text-sm font-bold text-gray-900 dark:text-white">RWF {{ telecom.productPrice }}</span>
                    <button @click="addToCart(telecom.productId, 1)" class="text-xs px-3 py-2 rounded-lg bg-gray-900 hover:bg-blue-600 text-white">Add to Cart</button>
                </div>
            </div>
        </div>

    </div>

</div>
</div>

<!-- ccessoir section -->



<div class="mt-4">
    <h1 class="text-red-500 font-semibold">
       Accessories
    </h1>
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">


    <div v-for="(access, index) in filteredAccessories" :key="index" class="product">
        <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <a :href="'/products/' + access.id" class="block">
                <img :src="access.filePath" :alt="access.productName" class="w-full h-56 object-cover rounded-t-lg" alt="product image" />
            </a>
            <div class="px-4 py-4">
                <a :href="'/products/' + access.productId" class="block">
                    <h5 class="text-sm font-semibold tracking-tight text-gray-900 dark:text-white">
                        {{ access.id }}</h5>
                </a>

                <div class="flex items-center justify-between mt-2">
                    <span class="text-sm font-bold text-gray-900 dark:text-white">RWF {{ access.productPrice }}</span>
                    <button @click="addToCart(access.id, 1)" class="text-xs px-3 py-2 rounded-lg bg-gray-900 hover:bg-blue-600 text-white">Add to Cart</button> </div>
            </div>
        </div>

    </div>

</div>
</div>

    </div>
    <div class="bg-white h-auto w-96 ml-3">


        <div class="image-slider mt-4 h-32 ">
            <!-- <h1 class="text-red-700 font-semibold">Sound System</h1> -->
            <img :src="currentImageTv" alt="Slider Image"  class="rounded-5 h-32 w-full"/>
          </div>


        <div class="border-rounded-full  items-center ml-4 mt-4">
            <img :src="ServiceUrl" class="h-auto "  alt="Image" />
        </div>

        <div class=" mt-7">
            <h1 class="text-center font-medium">
                Tech Support

            </h1>
            <img :src="TechUrl" class="h-auto "  alt="Image" />

        </div>



    </div>
  </div>




<!-- footer -->



  <footer class="footer p-10 bg-red-500 text-white mt-4 mb-2">
    <aside>
        <img :src="imageUrl" class="h-12 w-12 rounded-full align-middle "  alt="Image" />
      <p>ACME Industries Ltd.<br>Providing reliable tech since 1992</p>
    </aside>
    <nav>
      <h6 class="footer-title font-semibold text-xl">Services</h6>
      <a class="link link-hover">Branding</a>
      <a class="link link-hover">Design</a>
      <a class="link link-hover">Marketing</a>
      <a class="link link-hover">Advertisement</a>
    </nav>
    <nav>
      <h6 class="footer-title font-semibold text-xl">Company</h6>
      <a class="link link-hover">About us</a>
      <a class="link link-hover">Contact</a>
      <a class="link link-hover">Jobs</a>
      <a class="link link-hover">Press kit</a>
    </nav>
    <nav>
      <h6 class="footer-title font-semibold text-xl">Legal</h6>
      <a class="link link-hover">Terms of use</a>
      <a class="link link-hover">Privacy policy</a>
      <a class="link link-hover">Cookie policy</a>
    </nav>
  </footer>


    </div>
  </template>

  <script>
import axios from 'axios';

export default {
  data() {
    return {
        // for fetching data
        fetchedData: null,
        accessories:[],
        telecommunication:[],
        pollingInterval: null,
        electronics: [],
        searchQuery: '',

        //for sliding images
      imageUrl: '/image/logo.jpg',
      ServiceUrl: '/image/services.jpg',
      BannerUrl: '/image/banner.jpg',
      TechUrl:'/image/tech.jpeg',
      TvUrl:'/image/tv/tv.jpeg',

      Accessories1:'/image/accessories/adapter1.jpeg',
      Accessories2:'/image/accessories/adapter2.jpeg',
      Accessories3:'/image/accessories/adapter3.jpeg',
      Accessories4:'/image/accessories/remote1.jpeg',
      Accessories5:'/image/accessories/remote2.jpeg',
      Accessories6:'/image/accessories/wire1.jpeg',
      Accessories7:'/image/accessories/wire2.jpeg',



      Radio1Url:'/image/radio/radio1.jpeg',
      Radio2Url:'/image/radio/radio2.jpeg',
      Radio3Url:'/image/radio/radio3.jpeg',
      Radio4Url:'/image/radio/radio4.jpeg',

      Decoder1Url:'/image/decoder/decoder.jpeg',
      Decoder2Url:'/image/decoder/decoder1.jpeg',
      Decoder3Url:'/image/decoder/decoder2.jpeg',
      Decoder4Url:'/image/decoder/decoder3.jpeg',
      Decoder5Url:'/image/decoder/decoder4.jpeg',
      Decoder6Url:'/image/decoder/decoder5.jpeg',


      images: [
        'sound1.jpeg',
        'sound2.jpeg',
        'sound3.jpeg',
        'sound4.jpeg'
      ],

      dstv: [
        'canal1.jpeg',
        'canal2.jpeg',
        'canal3.jpeg',
        'dstv1.jpeg',
        'dstv2.jpeg',
        'dstv3.jpeg',
        'dstv4.jpeg',
      ],
      currentIndexSound: 0,
      intervalIdSound: null,
      currentIndexTv: 0,
      intervalIdTv: null,
      intervalDuration: 3000 // Change image every 3 seconds
    };
  },

  watch: {
  searchQuery(newValue) {
    console.log('Search query:', newValue);
  }
}
,
  computed: {

    firstImagePath() {
      if (this.electronics.filePath) {
        const paths = JSON.parse(this.electronics.filePath);
       console.log('Path',paths);
        if (paths.length > 0) {
          return paths[0];
        }
      }
      return null;
    },

    filteredTelecommunication() {
  console.log("Filtered Telecommunication computed");
  return this.telecommunication.filter(telecom => {
    return (telecom.productName && telecom.productName.toLowerCase().includes(this.searchQuery.toLowerCase())) ||
           (telecom.price && telecom.price.toString().toLowerCase().includes(this.searchQuery.toLowerCase()));
  });
},
filteredElectronics() {
  console.log("Filtered Electronics computed");
  return this.electronics.filter(product => {
    return (product.productName && product.productName.toLowerCase().includes(this.searchQuery.toLowerCase())) ||
           (product.price && product.price.toString().toLowerCase().includes(this.searchQuery.toLowerCase()));
  });
},
filteredAccessories() {
  console.log("Filtered Accessories computed");
  return this.accessories.filter(access => {
    return (access.productName && access.productName.toLowerCase().includes(this.searchQuery.toLowerCase())) ||
           (access.price && access.price.toString().toLowerCase().includes(this.searchQuery.toLowerCase()));
  });
},




    // slidr

    currentImageSound() {
        return `/image/${this.images[this.currentIndexSound]}`;
    },

    currentImageTv() {
        return `/image/dstv/${this.dstv[this.currentIndexTv]}`;
    }
  },
  mounted() {
    this.startSlidingSound();
    this.startSlidingTv();
    this.fetchData(); // Initial fetch
    this.pollingInterval = setInterval(() => {
    this.fetchData();
      }, 2000);
  },
  methods: {

    getImageUrl(path) {
      // Assuming you have a base URL where your images are hosted
      // Adjust this according to your setup
      return 'https://yourdomain.com/' + path;
    },

//slide images

    startSlidingSound() {
      this.intervalIdSound = setInterval(() => {
        this.currentIndexSound = (this.currentIndexSound + 1) % this.images.length;
      }, this.intervalDuration);
    },
    stopSlidingSound() {
      clearInterval(this.intervalIdSound);
    },

    startSlidingTv() {
      this.intervalIdTv = setInterval(() => {
        this.currentIndexTv = (this.currentIndexTv+ 1) % this.images.length;
      }, this.intervalDuration);
    },

    stopSlidingTv() {
      clearInterval(this.intervalIdTv);
    },

    // fetch data from database
    fetchData() {
        axios.get('/allData')
          .then(response => {
            this.fetchedData = response.data.result;
            this.electronics = response.data.topElectronic;
            this.telecommunication = response.data.topTelecommunication;

            this.accessories = response.data.accessories;
            console.log('Fetched data successfully', this.fetchedData);
            console.log('Electronic data', this.electronics);
            console.log('Tlecommunication data', this.telecommunication);
            console.log('Accessories data', this.accessories);
          })
          .catch(error => {
            console.error('Error fetching data', error);
          });
      },

methods: {
  decodeFilePaths(filePathJson) {
    return JSON.parse(filePathJson).map(path => path.replace(/\\/g, '/'));
  }
}

  },

  beforeDestroy() {
    this.stopSlidingSound();
    this.stopSlidingTv();
    clearInterval(this.pollingInterval);
  }


};
</script>


