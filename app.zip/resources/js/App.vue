<template>
    How To Install Vue 3 in Laravel 10 with Vite - TechvBlogs
</template>
